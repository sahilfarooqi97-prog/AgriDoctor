# Agri Doctor (Android) - Project skeleton

This is a minimal ready-to-open Android project skeleton for the **Agri Doctor** app (Kotlin + Jetpack Compose + Room).
It includes localization (English + Punjabi), Room entities/DAO, add/edit screen, Firestore sync placeholders and a GitHub Actions workflow file to build the APK as an artifact.

**Important:** This repository is a skeleton. Import it into Android Studio (Electric Eel or newer), add your keystore for signing, then Build -> Generate Signed Bundle / APK or run `./gradlew assembleRelease` after configuring signing in `app/build.gradle` or `gradle.properties`.

Included:
- app module with Kotlin sources (MainActivity, data model, Room, ViewModels, UI)
- resources: English + Punjabi (values/strings.xml and values-pa/strings.xml)
- assets/pestfert.json (sample entries)
- GitHub Actions workflow to build APK (assembleRelease)
- Sample logo (app_icon.png) - generated image included in project root

---

## Quick local build steps (summary)
1. Open project in Android Studio.
2. Let Gradle sync. Update compileSdk and plugin versions if prompted.
3. Add a `keystore.jks` and configure signing in `app/build.gradle` or `gradle.properties` (see README details inside `app` folder).
4. Build > Generate Signed Bundle / APK -> follow steps.
5. Or from terminal: `./gradlew assembleRelease` (after signing config).

If you want me to also prepare a full 200+ item dataset for `assets/pestfert.json` or a pre-populated Firestore JSON, tell me and I'll add it.
