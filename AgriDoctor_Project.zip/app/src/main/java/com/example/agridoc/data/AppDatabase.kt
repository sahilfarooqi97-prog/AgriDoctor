package com.example.agridoc.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [PestFertItem::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
}
