package com.example.agridoc.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Button
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.agridoc.data.PestFertItem

@Composable
fun AddEditScreen(onSaved: (PestFertItem) -> Unit) {
    var commonName by remember { mutableStateOf("") }
    var technicalName by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("pesticide") }
    var dose by remember { mutableStateOf("") }
    var uses by remember { mutableStateOf("") }
    var precautions by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Column(Modifier.padding(16.dp)) {
        OutlinedTextField(value = commonName, onValueChange = { commonName = it }, label = { Text("Common Name") })
        OutlinedTextField(value = technicalName, onValueChange = { technicalName = it }, label = { Text("Technical Name") })
        OutlinedTextField(value = type, onValueChange = { type = it }, label = { Text("Type") })
        OutlinedTextField(value = dose, onValueChange = { dose = it }, label = { Text("Dose") })
        OutlinedTextField(value = uses, onValueChange = { uses = it }, label = { Text("Uses") })
        OutlinedTextField(value = precautions, onValueChange = { precautions = it }, label = { Text("Precautions") })
        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes") })

        Button(onClick = {
            val item = PestFertItem(commonName.lowercase().replace(" ", "_"), type, commonName, technicalName, dose, uses, precautions, notes)
            onSaved(item)
        }) {
            Text("Save Entry")
        }
    }
}
