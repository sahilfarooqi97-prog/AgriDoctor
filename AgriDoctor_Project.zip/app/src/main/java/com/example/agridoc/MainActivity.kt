package com.example.agridoc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.ui.res.stringResource

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel(factory = androidx.lifecycle.viewmodel.compose.viewModelFactory { MainViewModel(applicationContext) })
            val items by vm.items.collectAsState()
            var query by remember { mutableStateOf("") }
            var currentLang by remember { mutableStateOf("en") }

            Scaffold(topBar = {
                TopAppBar(title = { Text(stringResource(R.string.agri_doctor_app_name)) }, actions = {
                    IconButton(onClick = {
                        currentLang = if (currentLang == "en") "pa" else "en"
                        LocalizationHelper.setLocale(this@MainActivity, currentLang)
                        recreate()
                    }) {
                        Icon(Icons.Default.Language, contentDescription = "Lang")
                    }
                })
            }) { padding ->
                Column(modifier = Modifier.padding(8.dp)) {
                    OutlinedTextField(value = query, onValueChange = {
                        query = it
                        vm.search(it)
                    }, label = { Text(stringResource(R.string.search_hint)) }, modifier = Modifier.fillMaxWidth())

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(items) { item ->
                            Card(modifier = Modifier
                                .fillMaxWidth()
                                .padding(4.dp)
                                .clickable { /* TODO: open detail/edit */ }) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(item.commonName, style = MaterialTheme.typography.h6)
                                    Text(item.technicalName, style = MaterialTheme.typography.subtitle2)
                                    Text(item.uses, maxLines = 2)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
