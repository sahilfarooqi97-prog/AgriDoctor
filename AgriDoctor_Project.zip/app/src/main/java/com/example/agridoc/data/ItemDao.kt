package com.example.agridoc.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ItemDao {
    @Query("SELECT * FROM items ORDER BY commonName ASC")
    suspend fun getAll(): List<PestFertItem>

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun getById(id: String): PestFertItem?

    @Query("SELECT * FROM items WHERE commonName LIKE '%' || :q || '%' OR technicalName LIKE '%' || :q || '%' ORDER BY commonName")
    suspend fun search(q: String): List<PestFertItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: PestFertItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<PestFertItem>)
}
