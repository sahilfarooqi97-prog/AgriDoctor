package com.example.agridoc

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocalizationHelper {
    fun setLocale(context: Context, lang: String) {
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = Configuration()
        config.setLocale(locale)
        context.resources.updateConfiguration(config, context.resources.displayMetrics)
    }
}
