package com.example.agridoc

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agridoc.data.AppDatabase
import com.example.agridoc.repo.Repository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel(context: Context) : ViewModel() {
    private val dbDeferred = async(context = kotlinx.coroutines.Dispatchers.IO) { /* createDatabase(context) placeholder */ null }
    private var repo: Repository? = null

    private val _items = MutableStateFlow<List<com.example.agridoc.data.PestFertItem>>(emptyList())
    val items: StateFlow<List<com.example.agridoc.data.PestFertItem>> = _items

    init {
        viewModelScope.launch {
            // In the real project call createDatabase(context) to get DB and repo
            // val db = dbDeferred.await() as AppDatabase
            // repo = Repository(db.itemDao())
            // _items.value = repo!!.all()
        }
    }

    fun search(q: String) {
        viewModelScope.launch {
            _items.value = repo?.search(q) ?: emptyList()
        }
    }
}
