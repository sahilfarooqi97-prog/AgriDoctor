package com.example.agridoc.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "items")
data class PestFertItem(
    @PrimaryKey val id: String,
    val type: String,
    val commonName: String,
    val technicalName: String,
    val dose: String,
    val uses: String,
    val precautions: String,
    val notes: String?
)
