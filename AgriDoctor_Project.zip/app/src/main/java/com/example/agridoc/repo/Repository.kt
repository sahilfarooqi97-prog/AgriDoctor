package com.example.agridoc.repo

import com.example.agridoc.data.ItemDao
import com.example.agridoc.data.PestFertItem

class Repository(private val dao: ItemDao) {
    suspend fun all() = dao.getAll()
    suspend fun search(q: String) = dao.search(q)
    suspend fun getById(id: String) = dao.getById(id)
    suspend fun insert(item: PestFertItem) = dao.insert(item)
    suspend fun insertAll(items: List<PestFertItem>) = dao.insertAll(items)
}
