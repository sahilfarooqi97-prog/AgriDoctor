rootProject.name = "AgriDoctor"
include(":app")
